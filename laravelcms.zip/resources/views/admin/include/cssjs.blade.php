<script src="/resources/plugs/jquery/jquery-3.3.1.min.js" ></script>

{{--bootstrap组件--}}
{{--<link rel="stylesheet" href="/resources/plugs/bootstrap/bootstrap.min.css" >--}}
<link rel="stylesheet" href="/resources/plugs/bootstrap/bootstrap.purple.min.css" >

<script src="/resources/plugs/bootstrap/popper.min.js"></script>
<script src="/resources/plugs/bootstrap/bootstrap.min.js"></script>
{{--bootstrap-dialog--}}
<script src="/resources/plugs/bootstrap/bootstrap.dialog.js"></script>

{{--日期选择器插件datetimepicker--}}
<link rel="stylesheet" href="/resources/plugs/flatpickr/flatpickr.min.css">
<script type="text/javascript" src="/resources/plugs/flatpickr/flatpickr.js"></script>
<script type="text/javascript" src="/resources/plugs/flatpickr/zh.js"></script>

{{--文件上传-插件地址：https://github.com/danielm/uploader--}}
<script src="/resources/plugs/dmuploader/jquery.dm-uploader.js"></script>

{{--serialize-object--}}
<script src="/resources/plugs/bootstrap/jquery.serialize-object.min.js"></script>

{{--ckeditor--}}
<script type="text/javascript" src="/resources/plugs/ckeditor/ckeditor.js"></script>

{{--awesome字体--}}
<link href="/resources/plugs/awesome/font/css/font-awesome.min.css" rel="stylesheet">

{{--样式--}}
<link rel="stylesheet" href="/resources/admin/css/style.css?v=2">