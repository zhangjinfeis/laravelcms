<!-- footer -->
<div id="footer">
    <div class="copyright">
        {{$config['copyright']}} <br>
        {{$config['beian']}}
    </div>
</div>
