
<script src="/resources/bootstrap/jquery.min.js" ></script>

<link rel="stylesheet" href="/resources/mobi/css/base.css">
<link rel="stylesheet" href="/resources/mobi/css/style.css">

<!-- swiper START 按需引入 -->
<link rel="stylesheet" href="/resources/mobi/swiper/swiper.min.css">
<script src="/resources/mobi/swiper/swiper.min.js"></script>

<!--图片预览工具-->
<link rel="stylesheet" href="/resources/mobi/baguetteBox/baguitteBox.css">
<script src="/resources/mobi/baguetteBox/baguitteBox.js"></script>


