<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
/**
 * 参数分类
 * @author kevin 2017-11-08
 * Class Pic
 * @package App
 */
class ConfigCate extends Model
{
    protected $table = 'config_cate';
    protected $dateFormat = 'U';


}
