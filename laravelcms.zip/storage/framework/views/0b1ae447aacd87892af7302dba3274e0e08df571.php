<?php $__env->startSection("content"); ?>
    <!-- page -->
        <!-- body -->
    <!-- body -->
    <div id="sub-main">
        <h1><?php echo e($page->title); ?></h1>
        <div class="com-p">
            <?php echo htmlspecialchars_decode($page->body); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("mobi.include.mother", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>