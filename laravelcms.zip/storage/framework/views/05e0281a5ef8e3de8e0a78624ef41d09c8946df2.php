<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>后台管理</title>
    <meta name="renderer" content="webkit">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <?php $__env->startSection('cssjs'); ?>
        <?php echo $__env->make('admin.include.cssjs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        
        <script>
            $.ajaxSetup({
                headers: { 'X-CSRF-TOKEN' : '<?php echo e(csrf_token()); ?>' }
            });
        </script>
    <?php echo $__env->yieldSection(); ?>
</head>
<body>


<div class="g-page-in">
    <?php echo $__env->yieldContent("content"); ?>
</div>
<script>
    (function(){
        var h = $(window).height();
        $('.g-page-in').css({'min-height':h-20});
    })();

</script>

<script src="/resources/admin/js/my.js"></script>

</body>
</html>