<?php $__env->startSection("content"); ?>
    <div id="sub-main">
        <div class="com-inner">
            <?php echo $__env->make('home.include.crumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="main-box clearfix">
                <div class="m-left">
                    <?php echo $__env->make('home.include.sidenav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('home.include.sidetalk', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
                <div class="m-right">
                    <div class="com-p">
                        <?php echo htmlspecialchars_decode($page->body); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("home.include.mother", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>