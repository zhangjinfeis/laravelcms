<!-- header -->
<div id="header">
    <a href="/mobi" class="logo"><img src="/resources/mobi/images/logo.png" alt=""></a>
    <div id="hamburger" class="">
        <i class="icon-bar"></i>
        <i class="icon-bar"></i>
        <i class="icon-bar"></i>
    </div>
</div>
<!-- menu -->
<div id="menu">
    <ul class="menu-nav">
        <?php $__currentLoopData = $menu1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="item"><a target="<?php echo e($vo['target']); ?>" href="<?php echo e($vo['url']); ?>"><?php echo e($vo['name']); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>