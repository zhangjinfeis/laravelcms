<?php $__env->startSection("content"); ?>

    <div class="u-breadcrumb">
        <ol>
            <li>公共模块</li>
            <li>链接</li>
            <li>链接列表</li>
        </ol>
    </div>
    <div class="h20"></div>

    <table class="table table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>查询类型</th>
                <th>公司/商标名称</th>
                <th>查询者称呼</th>
                <th>手机</th>
                <th>查询时间</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($vo->id); ?></td>
                <td>
                    <?php if($vo->type == 1): ?>
                        公司查询
                    <?php else: ?>
                        商标查询
                    <?php endif; ?>

                </td>
                <td>
                    <?php echo e($vo->name); ?>

                </td>
                <td>
                    <?php echo e($vo->contact_man); ?>

                </td>
                <td>
                    <?php echo e($vo->phone); ?>

                </td>
                <td>
                    <?php echo e($vo->created_at->format('Y-m-d H:i')); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($list->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.include.mother", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>