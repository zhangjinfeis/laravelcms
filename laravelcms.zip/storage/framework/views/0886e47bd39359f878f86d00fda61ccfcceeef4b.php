<?php $__env->startSection("content"); ?>
    <!-- page -->
        <!-- body -->
        <div id="sub-main">
            <div class="com-tabs">
                <a href="/mobi/about" class="item">公司简介</a>
                <a href="/mobi/zizhi" class="item active">企业资质</a>
                <a href="/mobi/huanjing" class="item">公司环境</a>
            </div>
            <div class="com-honor-list baguetteBox">
                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <a href="/image/<?php echo e($vo->thumb); ?>?a.jpg" data-caption="<?php echo e($vo->title); ?>" class="pic">
                        <img src="/image/<?php echo e($vo->thumb); ?>">
                    </a>
                    <div class="tit"><?php echo e($vo->title); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($list->appends($_GET)->links()); ?>

        </div>
    <!-- loading -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make("mobi.include.mother", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>