<?php $__env->startSection("content"); ?>
    <div class="u-breadcrumb">
        <a class="back" href="<?php echo e(url()->previous()); ?>" ><span class="fa fa-chevron-left"></span> 后退</a>
        <a class="back" href="javascript:window.location.reload();" ><span class="fa fa-repeat"></span> 刷新</a>
        <span class="name">新增角色</span>
    </div>
    <div class="h30"></div>



    <form>
        <div class="row">
            <div class="col-4">
                <div class="form-group">
                    <label for="name">角色名称</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="角色名称" value="" />
                    <small class="form-text text-muted">1-50个字符</small>
                </div>

                <div class="form-group">
                    <label for="url">描述</label>
                    <input type="text" class="form-control" id="description" name="description" placeholder="描述" value="">
                </div>
                <div class="h10"></div>
                <button type="submit" class="btn btn-primary" onclick="return post_create();">保存</button>
            </div>
            <div class="col-8">
                <label>选择权限</label>
                <?php $__currentLoopData = $power; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <div><?php echo e($vo['group']); ?></div>
                    <div>
                        <?php $__currentLoopData = $vo['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-control custom-control-inline custom-checkbox">
                                <input name="power[]" type="checkbox" class="custom-control-input" id="chcek<?php echo e($voo['id']); ?>" value="<?php echo e($voo['id']); ?>" />
                                <label class="custom-control-label" for="chcek<?php echo e($voo['id']); ?>"><?php echo e($voo['description']); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </form>

    <script>
        //提交新增
        function post_create(){
            $.ajax({
                type:'post',
                url:'/admin/manager_role/create',
                data:$('form').serialize(),
                success:function(res){
                    if(res.status == 0){
                        $boot.warn({text:res.msg},function(){
                            $('input[name='+res.field+']').focus();
                        });
                    }else{
                        $boot.success({text:res.msg},function(){
                            window.location = "<?php echo e(url()->previous()); ?>";
                        });
                    }
                }
            })
            return false;
        }


    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.include.mother", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>